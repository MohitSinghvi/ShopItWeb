# CHANGELOG

## 0.1.1

- (CHG) Update StanfordTagger::tag to return results for multiple sentences. This affects the return values for POSTagger::tag and NERTagger::tag
