<?php

namespace Nadar\Stemming;

interface StemmerInterface
{
    public static function stem($word);
}
