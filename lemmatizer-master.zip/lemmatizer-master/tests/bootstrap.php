<?php

/**
 * @file
 * Bootstrap requirements for testing.
 */

require 'src/Lemmatizer.php';
